package dev.nxnative.launcher.nativebridge

class NativeHostBridge(
    private val progressListener: ((current: Int, total: Int) -> Unit)? = null
) {
    companion object {
        init {
            System.loadLibrary("nxnative_host")
        }
    }

    external fun probeVulkanDevice(): String

    external fun runPreparePipeline(
        dumpDir: String,
        packDir: String,
        patches: String,
        workers: Int
    ): String

    @Suppress("unused")
    fun onNativeShaderProgress(current: Int, total: Int) {
        progressListener?.invoke(current, total)
    }
}
