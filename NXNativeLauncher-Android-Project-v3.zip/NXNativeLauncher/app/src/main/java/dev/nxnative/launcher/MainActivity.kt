package dev.nxnative.launcher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import dev.nxnative.launcher.model.BuiltinGameCatalog
import dev.nxnative.launcher.model.GameProfile
import dev.nxnative.launcher.model.GpuDriverEntry
import dev.nxnative.launcher.model.PackStatus
import dev.nxnative.launcher.nativebridge.NativeHostBridge
import dev.nxnative.launcher.service.PackPrepareService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF82B1FF),
                    secondary = Color(0xFF80CBC4),
                    background = Color(0xFF0F1115),
                    surface = Color(0xFF181B22)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    NXNativeAppScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NXNativeAppScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    var games by remember { mutableStateOf(BuiltinGameCatalog.getDefaultGames()) }
    var selectedGameForSheet by remember { mutableStateOf<GameProfile?>(null) }
    var gpuInfo by remember { mutableStateOf("Probing GPU...") }
    var buildLogs by remember {
        mutableStateOf(
            listOf(
                "[info] NXNative Host v0.1.8-legacy (Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT})",
                "[info] Shader library target: shaders/v-c679ddfbc5db/dmsh_vk.lib",
                "[info] Ready to scan dump folders (NSP/NSZ/XCI/NUP)"
            )
        )
    }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.all { it }
        val msg = if (granted) "Izin penyimpanan (Android 7–10) diberikan" else "Izin penyimpanan ditolak"
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        buildLogs = buildLogs + "[perm] $msg"
    }

    var availableDrivers by remember {
        mutableStateOf(
            listOf(
                GpuDriverEntry("sys", "System GPU Driver (Vulkan / GLES 3.0)", "Auto", "Android Native", true),
                GpuDriverEntry("turnip_25", "Mesa Turnip Adreno v25.0.0", "Adreno 6xx/7xx", "25.0.0", true),
                GpuDriverEntry("panvk_dev", "PanVK Mali Placed-Map", "Mali / Immortalis", "2026.10", true)
            )
        )
    }
    var activeDriverId by remember { mutableStateOf("sys") }
    var workerThreads by remember { mutableIntStateOf(4) }

    LaunchedEffect(Unit) {
        val bridge = NativeHostBridge()
        gpuInfo = withContext(Dispatchers.IO) { bridge.probeVulkanDevice() }
        buildLogs = buildLogs + "[gpu] $gpuInfo"
    }

    val freeSpaceGb = remember {
        val stat = StatFs(Environment.getDataDirectory().path)
        (stat.availableBlocksLong * stat.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("NXNative Host", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = String.format("Free: %.1f GiB • %s", freeSpaceGb, gpuInfo),
                            fontSize = 11.sp,
                            color = Color(0xFF9AA4B2)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        buildLogs = buildLogs + "[scan] Rescanned /storage/emulated/0/Switch2/dumps (${games.size} titles matched)"
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Rescan Library")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.SportsEsports, null) },
                    label = { Text("Games") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Memory, null) },
                    label = { Text("GPU & Drivers") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Terminal, null) },
                    label = { Text("Build Logs") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Settings, null) },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> GamesLibraryTab(
                    games = games,
                    onOpenSheet = { selectedGameForSheet = it },
                    onPrepareGame = { target ->
                        scope.launch {
                            val svcIntent = Intent(context, PackPrepareService::class.java).apply {
                                putExtra("game_name", target.name)
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                context.startForegroundService(svcIntent)
                            } else {
                                context.startService(svcIntent)
                            }

                            games = games.map {
                                if (it.titleId == target.titleId) it.copy(packStatus = PackStatus.PREPARING) else it
                            }
                            buildLogs = buildLogs + "[prepare] Starting static AOT rewrite for ${target.name} (${target.titleId})..."

                            val bridge = NativeHostBridge { cur, tot ->
                                games = games.map {
                                    if (it.titleId == target.titleId) it.copy(shaderProgress = cur to tot) else it
                                }
                            }

                            val packOutDir = File(context.filesDir, "packs/${target.titleId}").absolutePath
                            val result = withContext(Dispatchers.IO) {
                                bridge.runPreparePipeline(
                                    dumpDir = target.dumpPath + target.titleId,
                                    packDir = packOutDir,
                                    patches = target.patchRules,
                                    workers = workerThreads
                                )
                            }

                            context.stopService(svcIntent)
                            buildLogs = buildLogs + "[prepare] Finished ${target.name}: $result"

                            games = games.map {
                                if (it.titleId == target.titleId) {
                                    it.copy(
                                        packStatus = if (it.activeMods.isNotEmpty()) PackStatus.READY_WITH_MODS else PackStatus.READY,
                                        shaderProgress = 480 to 480
                                    )
                                } else it
                            }
                        }
                    },
                    onPlayGame = { game ->
                        val intent = Intent(context, GameSurfaceActivity::class.java).apply {
                            putExtra("title_id", game.titleId)
                            putExtra("game_name", game.name)
                            putExtra("target_fps", game.targetFps)
                            putExtra("resolution", game.defaultResolution)
                            putExtra("driver", game.customDriver)
                        }
                        context.startActivity(intent)
                    }
                )

                1 -> GpuDriversTab(
                    gpuInfo = gpuInfo,
                    drivers = availableDrivers,
                    activeDriverId = activeDriverId,
                    onSelectDriver = { drv ->
                        activeDriverId = drv.id
                        games = games.map { it.copy(customDriver = drv.name) }
                        buildLogs = buildLogs + "[driver] Selected ${drv.name} (${drv.version})"
                    }
                )

                2 -> BuildLogsTab(
                    logs = buildLogs,
                    onClear = { buildLogs = listOf("[info] Logs cleared.") }
                )

                3 -> SettingsTab(
                    workerThreads = workerThreads,
                    onChangeWorkers = { workerThreads = it },
                    onRequestStorageAccess = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            // Android 11+ (API 30+)
                            if (!Environment.isExternalStorageManager()) {
                                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                }
                                context.startActivity(intent)
                            } else {
                                Toast.makeText(context, "All Files Access sudah aktif", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            // Android 7.0 - 10 (API 24 - 29)
                            val readGranted = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.READ_EXTERNAL_STORAGE
                            ) == PackageManager.PERMISSION_GRANTED
                            val writeGranted = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.WRITE_EXTERNAL_STORAGE
                            ) == PackageManager.PERMISSION_GRANTED

                            if (!readGranted || !writeGranted) {
                                legacyPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.READ_EXTERNAL_STORAGE,
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                                    )
                                )
                            } else {
                                Toast.makeText(context, "Izin penyimpanan sudah aktif", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                )
            }
        }
    }

    selectedGameForSheet?.let { game ->
        ModalBottomSheet(onDismissRequest = { selectedGameForSheet = null }) {
            GameDetailSheet(
                game = game,
                onDismiss = { selectedGameForSheet = null },
                onBackupSave = {
                    buildLogs = buildLogs + "[save] Backed up ${game.name} save to ${game.titleId}-backup.zip"
                    selectedGameForSheet = null
                },
                onDeletePack = {
                    val packDir = File(context.filesDir, "packs/${game.titleId}")
                    packDir.deleteRecursively()
                    games = games.map {
                        if (it.titleId == game.titleId) it.copy(packStatus = PackStatus.NOT_PREPARED, shaderProgress = 0 to 480) else it
                    }
                    buildLogs = buildLogs + "[pack] Deleted pack for ${game.name} (saves kept)"
                    selectedGameForSheet = null
                }
            )
        }
    }
}

@Composable
fun GamesLibraryTab(
    games: List<GameProfile>,
    onOpenSheet: (GameProfile) -> Unit,
    onPrepareGame: (GameProfile) -> Unit,
    onPlayGame: (GameProfile) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(games, key = { it.titleId }) { game ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenSheet(game) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(game.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                "${game.titleId} • v${game.version} • ${game.defaultResolution}",
                                fontSize = 12.sp,
                                color = Color(0xFF9AA4B2),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        StatusBadge(game.packStatus)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (game.packStatus == PackStatus.PREPARING) {
                        val (cur, tot) = game.shaderProgress
                        val progress = if (tot > 0) cur.toFloat() / tot.toFloat() else 0f
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(6.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Translating shaders: $cur of $tot (${(progress * 100).toInt()}%)",
                            fontSize = 11.sp,
                            color = Color(0xFF82B1FF)
                        )
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (game.packStatus == PackStatus.NOT_PREPARED) {
                                Button(
                                    onClick = { onPrepareGame(game) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Build, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Prepare Pack")
                                }
                            } else {
                                Button(
                                    onClick = { onPlayGame(game) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Play (${game.targetFps} FPS)")
                                }
                            }
                            OutlinedButton(onClick = { onOpenSheet(game) }) {
                                Text("Details")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: PackStatus) {
    val (bg, fg) = when (status) {
        PackStatus.NOT_PREPARED -> Color(0xFF2B303B) to Color(0xFFB0BAC9)
        PackStatus.PREPARING -> Color(0xFF1E3A5F) to Color(0xFF82B1FF)
        PackStatus.READY -> Color(0xFF1B4332) to Color(0xFF80CBC4)
        PackStatus.READY_WITH_MODS -> Color(0xFF3B2F63) to Color(0xFFD0BCFF)
    }
    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(status.label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GpuDriversTab(
    gpuInfo: String,
    drivers: List<GpuDriverEntry>,
    activeDriverId: String,
    onSelectDriver: (GpuDriverEntry) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Host GPU Readiness", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(gpuInfo, fontSize = 13.sp, color = Color(0xFF80CBC4))
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Mendukung Vulkan 1.0+ maupun fallback OpenGL ES 3.0 untuk perangkat Android 7.0 hingga 11+.",
                        fontSize = 12.sp,
                        color = Color(0xFF9AA4B2)
                    )
                }
            }
        }
        items(drivers) { driver ->
            val selected = driver.id == activeDriverId
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) Color(0xFF1E293B) else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectDriver(driver) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = selected, onClick = { onSelectDriver(driver) })
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(driver.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "${driver.architecture} • Version ${driver.version}",
                            fontSize = 12.sp,
                            color = Color(0xFF9AA4B2)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BuildLogsTab(logs: List<String>, onClear: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Build & Runtime Digest", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            TextButton(onClick = onClear) { Text("Clear") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0C0F), RoundedCornerShape(10.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(logs) { line ->
                Text(
                    text = line,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Color(0xFFD1D5DB)
                )
            }
        }
    }
}

@Composable
fun SettingsTab(
    workerThreads: Int,
    onChangeWorkers: (Int) -> Unit,
    onRequestStorageAccess: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Host & Rewriter Settings", fontWeight = FontWeight.Bold, fontSize = 16.sp)

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Shader Translator Workers: $workerThreads", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = workerThreads.toFloat(),
                    onValueChange = { onChangeWorkers(it.toInt().coerceIn(1, 8)) },
                    valueRange = 1f..8f,
                    steps = 6
                )
                Text(
                    "Gunakan 2–4 worker pada perangkat Android versi lama dengan RAM terbatas.",
                    fontSize = 11.sp,
                    color = Color(0xFF9AA4B2)
                )
            }
        }

        Button(onClick = onRequestStorageAccess, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FolderOpen, null)
            Spacer(Modifier.width(8.dp))
            Text("Grant Storage Access (Android 7.0 – 11+)")
        }
    }
}

@Composable
fun GameDetailSheet(
    game: GameProfile,
    onDismiss: () -> Unit,
    onBackupSave: () -> Unit,
    onDeletePack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(game.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Title ID: ${game.titleId}", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        Text("Main Build ID: ${game.mainBuildId}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF9AA4B2))
        Text("SDK Build ID: ${game.sdkBuildId}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF9AA4B2))

        HorizontalDivider()
        Text("Active Binary Patches / Mods:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        game.activeMods.forEach { mod ->
            Text("• $mod", fontSize = 12.sp, color = Color(0xFF80CBC4))
        }

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = onBackupSave, modifier = Modifier.weight(1f)) {
                Text("Back Up Saves")
            }
            OutlinedButton(
                onClick = onDeletePack,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF5350))
            ) {
                Text("Delete Pack")
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
