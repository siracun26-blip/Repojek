package dev.nxnative.launcher

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.sin

class GameSurfaceActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gameName = intent.getStringExtra("game_name") ?: "Unknown Title"
        val titleId = intent.getStringExtra("title_id") ?: "0000000000000000"
        val targetFps = intent.getIntExtra("target_fps", 60)
        val resolution = intent.getStringExtra("resolution") ?: "1280x720"
        val driver = intent.getStringExtra("driver") ?: "System GPU Driver"

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                InGameRuntimeScreen(
                    gameName = gameName,
                    titleId = titleId,
                    targetFps = targetFps,
                    resolution = resolution,
                    driver = driver,
                    onStopGame = { finish() }
                )
            }
        }
    }
}

@Composable
fun InGameRuntimeScreen(
    gameName: String,
    titleId: String,
    targetFps: Int,
    resolution: String,
    driver: String,
    onStopGame: () -> Unit
) {
    var panelOpen by remember { mutableStateOf(false) }
    var showHud by remember { mutableStateOf(true) }
    var fpsCap by remember { mutableIntStateOf(targetFps) }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(3)
                    setRenderer(object : GLSurfaceView.Renderer {
                        private var tick = 0f
                        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                            GLES30.glClearColor(0.06f, 0.09f, 0.14f, 1.0f)
                        }
                        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
                            GLES30.glViewport(0, 0, width, height)
                        }
                        override fun onDrawFrame(gl: GL10?) {
                            tick += 0.03f
                            val pulse = 0.08f + 0.04f * sin(tick)
                            GLES30.glClearColor(0.05f, pulse, 0.16f, 1.0f)
                            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
                        }
                    })
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (showHud) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(14.dp)
                    .background(Color(0xAA0F1115), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "$fpsCap fps • ${String.format("%.1f", 1000.0 / fpsCap)} ms",
                    color = Color(0xFF80CBC4),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "$gameName ($resolution)",
                    color = Color.White,
                    fontSize = 11.sp
                )
            }
        }

        IconButton(
            onClick = { panelOpen = !panelOpen },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .background(Color(0xAA181B22), RoundedCornerShape(10.dp))
        ) {
            Icon(Icons.Default.Tune, contentDescription = "In-Game Panel", tint = Color.White)
        }

        AnimatedVisibility(
            visible = panelOpen,
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Card(
                modifier = Modifier
                    .width(300.dp)
                    .fillMaxHeight()
                    .padding(12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xEE181B22))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp).fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("In-Game Panel", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        IconButton(onClick = { panelOpen = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Text("Title ID: $titleId", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF9AA4B2))
                    Text("Driver: $driver", fontSize = 12.sp, color = Color(0xFF82B1FF))

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Performance HUD", fontSize = 13.sp)
                        Switch(checked = showHud, onCheckedChange = { showHud = it })
                    }

                    Text("Frame Rate Cap: $fpsCap FPS", fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(30, 60).forEach { cap ->
                            FilterChip(
                                selected = fpsCap == cap,
                                onClick = { fpsCap = cap },
                                label = { Text("$cap FPS") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Button(
                        onClick = onStopGame,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Stop the game", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
