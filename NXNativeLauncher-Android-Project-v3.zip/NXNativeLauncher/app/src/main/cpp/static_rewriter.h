#pragma once
#include <string>
#include <vector>
#include <cstdint>

namespace nxnative {

struct RewriteResult {
    bool success;
    std::string buildId;
    size_t codeBytesRewritten;
    size_t patchesApplied;
    std::string errorMessage;
};

class StaticRewriter {
public:
    static RewriteResult rewriteMainExecutable(
        const std::string& dumpExefsDir,
        const std::string& outputPackDir,
        const std::string& modPatchesRules
    );

    static size_t applyBinaryPatches(
        std::vector<uint8_t>& binaryBuffer,
        const std::string& patchSubmission
    );
};

} // namespace nxnative
