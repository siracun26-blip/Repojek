cmake_minimum_required(VERSION 3.22.1)
project("nxnative_host")

add_library(nxnative_host SHARED
    native_bridge.cpp
    static_rewriter.cpp
    shader_translator.cpp
)

find_library(log-lib log)
find_library(android-lib android)

# Vulkan dimuat secara dinamis via dlopen agar tidak crash saat startup di Android 7.0 - 9.0
target_link_libraries(nxnative_host
    ${log-lib}
    ${android-lib}
)
