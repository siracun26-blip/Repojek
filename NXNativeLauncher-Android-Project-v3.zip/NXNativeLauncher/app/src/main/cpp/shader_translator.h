#pragma once
#include <string>
#include <functional>

namespace nxnative {

struct ShaderBuildStats {
    int totalShaders;
    int translatedShaders;
    int reusedShaders;
    int failedShaders;
    std::string libHash;
};

class ShaderTranslator {
public:
    static ShaderBuildStats buildShaderLibrary(
        const std::string& packDir,
        int workerThreads,
        std::function<void(int current, int total)> onProgress
    );
};

} // namespace nxnative
