#include <jni.h>
#include <string>
#include <dlfcn.h>
#include <vulkan/vulkan.h>
#include "static_rewriter.h"
#include "shader_translator.h"

// Tipe fungsi dinamis Vulkan agar aman pada Android 7.0 - 9.0 tanpa link statis libvulkan.so
typedef VkResult (VKAPI_PTR *PFN_vkCreateInstance_dyn)(const VkInstanceCreateInfo*, const VkAllocationCallbacks*, VkInstance*);
typedef VkResult (VKAPI_PTR *PFN_vkEnumeratePhysicalDevices_dyn)(VkInstance, uint32_t*, VkPhysicalDevice*);
typedef void (VKAPI_PTR *PFN_vkGetPhysicalDeviceProperties_dyn)(VkPhysicalDevice, VkPhysicalDeviceProperties*);
typedef void (VKAPI_PTR *PFN_vkDestroyInstance_dyn)(VkInstance, const VkAllocationCallbacks*);

extern "C" JNIEXPORT jstring JNICALL
Java_dev_nxnative_launcher_nativebridge_NativeHostBridge_probeVulkanDevice(
    JNIEnv* env,
    jobject /* thiz */
) {
    void* vkLib = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
    if (!vkLib) {
        return env->NewStringUTF("OpenGL ES 3.0 Fallback (Vulkan tidak ditemukan)");
    }

    auto pCreateInstance = reinterpret_cast<PFN_vkCreateInstance_dyn>(dlsym(vkLib, "vkCreateInstance"));
    auto pEnumDevices = reinterpret_cast<PFN_vkEnumeratePhysicalDevices_dyn>(dlsym(vkLib, "vkEnumeratePhysicalDevices"));
    auto pGetProps = reinterpret_cast<PFN_vkGetPhysicalDeviceProperties_dyn>(dlsym(vkLib, "vkGetPhysicalDeviceProperties"));
    auto pDestroyInstance = reinterpret_cast<PFN_vkDestroyInstance_dyn>(dlsym(vkLib, "vkDestroyInstance"));

    if (!pCreateInstance || !pEnumDevices || !pGetProps || !pDestroyInstance) {
        dlclose(vkLib);
        return env->NewStringUTF("OpenGL ES 3.0 Fallback (Simbol Vulkan tidak lengkap)");
    }

    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "NXNativeHost";
    appInfo.apiVersion = VK_API_VERSION_1_0; // Gunakan Vulkan 1.0 base agar kompatibel dengan Android 7.0+

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;

    VkInstance instance = VK_NULL_HANDLE;
    if (pCreateInstance(&createInfo, nullptr, &instance) != VK_SUCCESS) {
        dlclose(vkLib);
        return env->NewStringUTF("OpenGL ES 3.0 Fallback (Init Vulkan gagal)");
    }

    uint32_t deviceCount = 0;
    pEnumDevices(instance, &deviceCount, nullptr);
    std::string result = "Vulkan Ready | GPUs: " + std::to_string(deviceCount);
    if (deviceCount > 0) {
        VkPhysicalDevice devices[4];
        uint32_t count = deviceCount > 4 ? 4 : deviceCount;
        pEnumDevices(instance, &count, devices);
        VkPhysicalDeviceProperties props{};
        pGetProps(devices[0], &props);
        result = std::string(props.deviceName) + " (Vulkan " +
                 std::to_string(VK_VERSION_MAJOR(props.apiVersion)) + "." +
                 std::to_string(VK_VERSION_MINOR(props.apiVersion)) + ")";
    }

    pDestroyInstance(instance, nullptr);
    dlclose(vkLib);
    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_nxnative_launcher_nativebridge_NativeHostBridge_runPreparePipeline(
    JNIEnv* env,
    jobject thiz,
    jstring dumpDirJ,
    jstring packDirJ,
    jstring patchesJ,
    jint workers
) {
    const char* dumpCStr = env->GetStringUTFChars(dumpDirJ, nullptr);
    const char* packCStr = env->GetStringUTFChars(packDirJ, nullptr);
    const char* patchCStr = env->GetStringUTFChars(patchesJ, nullptr);

    std::string dumpDir(dumpCStr);
    std::string packDir(packCStr);
    std::string patches(patchCStr);

    env->ReleaseStringUTFChars(dumpDirJ, dumpCStr);
    env->ReleaseStringUTFChars(packDirJ, packCStr);
    env->ReleaseStringUTFChars(patchesJ, patchCStr);

    auto rw = nxnative::StaticRewriter::rewriteMainExecutable(dumpDir + "/exefs", packDir, patches);
    if (!rw.success) {
        std::string err = "ERROR: " + rw.errorMessage;
        return env->NewStringUTF(err.c_str());
    }

    jclass cls = env->GetObjectClass(thiz);
    jmethodID onProgressMid = env->GetMethodID(cls, "onNativeShaderProgress", "(II)V");

    auto sh = nxnative::ShaderTranslator::buildShaderLibrary(
        packDir,
        workers,
        [&](int cur, int tot) {
            if (onProgressMid != nullptr) {
                env->CallVoidMethod(thiz, onProgressMid, cur, tot);
            }
        }
    );

    std::string summary = "OK|build_id=" + rw.buildId +
                          "|bytes=" + std::to_string(rw.codeBytesRewritten) +
                          "|patches=" + std::to_string(rw.patchesApplied) +
                          "|shaders=" + std::to_string(sh.translatedShaders) + "/" + std::to_string(sh.totalShaders) +
                          "|lib=" + sh.libHash;
    return env->NewStringUTF(summary.c_str());
}
