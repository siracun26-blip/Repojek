# NXNative Launcher (Android 7.0 – 11+ & GitHub Actions Ready)

Proyek Android (Kotlin + Jetpack Compose + C++17 JNI/NDK) yang mendukung **Android 7.0 (API 24) hingga Android 11+ (API 30+)** dan sudah dilengkapi **GitHub Actions Workflow** untuk kompilasi APK otomatis di cloud tanpa perlu menginstal Android Studio di PC.

## Cara Build APK Otomatis via GitHub
1. Buat repositori baru di **GitHub** (misalnya `nxnative-launcher`).
2. Ekstrak seluruh isi folder `NXNativeLauncher` dari file ZIP ini dan unggah (*upload* / `git push`) ke branch `main` repositori GitHub Anda (pastikan folder `.github/workflows/build-apk.yml` ikut terunggah).
3. Buka tab **Actions** di repositori GitHub Anda.
4. Workflow **Build Android APK (Legacy & Android 11+)** akan berjalan otomatis (atau klik **Run workflow** secara manual).
5. Setelah centang hijau selesai (~2–4 menit), gulir ke bagian **Artifacts** di halaman workflow tersebut dan unduh **`NXNativeLauncher-debug-apk`**.
6. Ekstrak ZIP artifact dan instal `app-debug.apk` di perangkat Android Anda (Android 7.0 hingga 11+).
